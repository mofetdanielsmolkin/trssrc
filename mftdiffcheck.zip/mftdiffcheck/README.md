# Moodle Plugin Migration Scripts — User Manual

Two Bash scripts for moving the extra plugins of an existing Moodle instance into a new custom build:

| Script | What it does |
|---|---|
| `moodle_extra_dirs.sh` | Finds the folders that exist in the current instance but **not** in the custom build `tar.gz` (extra plugins installed on the server). Compares **folder structure only**; files are ignored and nothing is extracted. |
| `bkplgs.sh` | Backs those folders up from the current instance, and restores them into the new instance. |
| `mkplgpkg.sh` | Packs one plugin folder into a `tar.gz` install package named with Moodle's convention, e.g. `atto_myplugin.tar.gz`. |

---

## 1. Setup

Copy both scripts to one folder on the server and make them executable:

```bash
mkdir -p /root/scripts
cp moodle_extra_dirs.sh bkplgs.sh mkplgpkg.sh /root/scripts/
chmod +x /root/scripts/*.sh
cd /root/scripts
```

Folder layout after a full run:

```
/root/scripts/
├── moodle_extra_dirs.sh
├── bkplgs.sh
├── mkplgpkg.sh
├── ignorelist        ← optional: folders the diff should skip
├── bkplgs.txt        ← list of folders to back up (created in step 2 below)
├── bkplgs/           ← backups (created automatically by the first backup)
└── plgpkgs/          ← plugin packages (created automatically by mkplgpkg.sh)
```

**Requirements:** Linux, Bash 4+, GNU `find`, `tar`, `gzip`, `cp`. Run as **root** so file ownership (e.g. `www-data`) is preserved on copy.

**Instance layout assumed:** the Moodle code is in an `app` folder inside the instance main folder, for example:

```
/var/app/moodle45lgs/0.3.3.20260618/app/     ← current instance
/var/app/moodle45lgs/0.3.9.20261118/app/     ← new instance
```

---

## 2. Typical workflow

```bash
cd /root/scripts

# 1. Find the extra plugins (one line per plugin) and save the list
./moodle_extra_dirs.sh -t /path/to/custom_build.tar.gz /var/app/moodle45lgs/0.3.3.20260618 > bkplgs.txt

# 2. Review / edit the list
vi bkplgs.txt

# 3. Back them up (preview first with -n)
./bkplgs.sh backup -n
./bkplgs.sh backup

# 4. Deploy the new build, then copy the plugins into it (preview first with -n)
./bkplgs.sh restore -n /var/app/moodle45lgs/0.3.9.20261118/app/
./bkplgs.sh restore    /var/app/moodle45lgs/0.3.9.20261118/app/

# 5. Fix ownership if needed and run the Moodle upgrade
#    (e.g. php admin/cli/upgrade.php in the new app folder)
```

> **Important:** use `-t` in step 1. The default output of `moodle_extra_dirs.sh` lists only the deepest sub-folders. Copying only those would miss the files in the plugin's own folder (`version.php`, `lib.php` …). With `-t` each line is the whole plugin folder.

---

## 3. `moodle_extra_dirs.sh`

### Usage

```bash
./moodle_extra_dirs.sh [options] <custom_build.tar.gz> <instance_path>
```

| Argument | Meaning |
|---|---|
| `<custom_build.tar.gz>` | The custom Moodle build archive |
| `<instance_path>` | Main folder of the existing instance (the folder that **contains** `app`) |

### Options

| Option | Meaning |
|---|---|
| *(none)* | Show the **deepest** extra folders only. A folder whose sub-folders are listed is not shown as its own row. |
| `-t` | **Top-level only**: one row per extra plugin (e.g. `.../app/local/customplugin`). Use this for `bkplgs.txt`. |
| `-f` | **Full**: every extra folder, parents and sub-folders. |
| `-r` | Print paths relative to `app` (e.g. `local/customplugin`) instead of full paths. |
| `-i FILE` | Use this ignore list file (see below). |
| `-p PATH` | An extra folder in the archive whose contents count as if they were inside `app`. Can be repeated. Default: `PrivatePlugins/lib`. |
| `-P` | Do not use any extra source folder. |
| `-a NAME` | Name of the application folder, if not `app`. |
| `-h` | Help. |

### Output example

For the same plugin, the three modes print:

```
# default (deepest)
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse/classes/local/delta
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse/db
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse/lang/he
...

# -t
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse

# -f
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse/classes
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse/classes/local
...
```

Folder paths go to **stdout**; `Info:` / `Error:` messages go to **stderr**. So `> bkplgs.txt` saves only the paths.

### How the archive is read

- The `app` folder is found inside the archive automatically (`app/`, `./app/`, `moodle/app/` …).
- `PrivatePlugins/lib` in the archive is treated as part of `app`: `PrivatePlugins/lib/mod/subcourse` counts as `app/mod/subcourse`. If the archive has no `PrivatePlugins/lib`, it is skipped with an `Info:` line and the run continues.
- Archives packed on Windows (`\` separators) and non-English (e.g. Hebrew) folder names are handled.

### Ignore list (`ignorelist`)

Folders that should **not** be scanned at all. The script uses a file named `ignorelist` next to the script, or in the current folder, or the file given with `-i`.

```
# folders to skip (relative to app/)
local/accessibility
mod/choicegroup
```

- One folder per line, relative to `app`. The folder **and everything under it** is skipped.
- Exact names only: `local/accessibility` does **not** hide `local/accessibilitytools`.
- Blank lines, `#` comments, leading `./` or `app/`, extra slashes and Windows line endings are accepted.

### Messages

| Message | Meaning |
|---|---|
| `Info: archive app folder: '...'` | Where `app` was found inside the archive |
| `Info: extra source folder: '...' (treated as 'app/')` | `PrivatePlugins/lib` (or `-p`) was found and is used |
| `Info: extra source folder '...' not found in archive - skipped` | No such folder in this archive; not an error |
| `Info: ignore list: ... (N entries)` | An ignore list is in use |
| `Info: N folder(s) found in instance but not in archive` | Number of rows printed |
| `Error: two arguments required.` | Give exactly the archive and the instance path |
| `Error: cannot read archive` / `not a valid gzip archive` | Wrong path, no permission, or a broken / partly uploaded file |
| `Error: 'app' folder not found in: ...` | Pass the main folder (above `app`), or set `-a` |
| `Error: no 'app/' folder found inside the archive` | Check the archive with `tar -tzf build.tar.gz \| head` |

---

## 4. `bkplgs.sh`

### Usage

```bash
./bkplgs.sh backup  [options] [instance_path]
./bkplgs.sh restore [options] <new_app_path>
```

| Action | Copies |
|---|---|
| `backup` | each folder in `bkplgs.txt` → `<script folder>/bkplgs/<path inside app>` |
| `restore` | `<script folder>/bkplgs/<path inside app>` → `<new_app_path>/<path inside app>` |

Example: `/var/app/moodle45lgs/0.3.3.20260618/app/local/custom` → `bkplgs/local/custom` → `/var/app/moodle45lgs/0.3.9.20261118/app/local/custom`

- `backup` needs **no path** when `bkplgs.txt` has full paths (the output of `moodle_extra_dirs.sh`). Give `[instance_path]` only if the list has relative lines like `local/custom`.
- `restore` always needs the new instance path. The main folder or its `app` folder are both accepted.

### Options

| Option | Meaning |
|---|---|
| `-n` | **Dry run**: show what would happen, change nothing |
| `-o` | **Overwrite**. Backup: replace an existing backup copy. Restore: copy over an existing folder (files are overwritten, nothing is deleted). Without `-o`, existing targets are skipped. |
| `-l FILE` | Use this list file instead of `bkplgs.txt` |
| `-b DIR` | Use this backup folder instead of `<script folder>/bkplgs` |
| `-h` | Help |

### The list file (`bkplgs.txt`)

Looked up next to the script, then in the current folder, or the file given with `-l`.

```
/var/app/moodle45lgs/0.3.3.20260618/app/ai/placement/aiopenresponse
/var/app/moodle45lgs/0.3.3.20260618/app/local/customplugin
```

- One folder per line: full path (recommended) or relative to `app`.
- Blank lines, `#` comments and `Info:` / `Error:` lines are ignored.
- If a folder and one of its sub-folders are both listed, only the parent is copied.
- Paths containing `..` are refused.

### The backup folder (`bkplgs/`)

- Created next to the scripts on the first `backup` if it does not exist (permissions `700`, root only). An existing one is used as is.
- `restore` never creates it; if it is missing there is nothing to restore and the script stops.
- Must not exist as a **file**. If an old list file is named `bkplgs`, the script stops and shows the `mv` command to rename it to `bkplgs.txt`.

### What is preserved

Owner, group, permissions, timestamps and symlinks (`cp -a`).

### Output

Each folder gets one status line, then a summary:

```
COPIED   local/customplugin
SKIP     local/existing  (already exists: ..., use -o)
MISSING  local/gone  (not found: ...)
WOULD    local/customplugin            ← dry run

Done: 2 copied, 1 skipped, 1 failed
```

Exit code is `0` when nothing failed, non-zero otherwise.

---

## 5. `mkplgpkg.sh`

Packs a single plugin folder into a `tar.gz` with the layout of a Moodle plugin install package: **one top folder named after the plugin**, with the plugin files inside.

### Usage

```bash
./mkplgpkg.sh [options] <plugin_path>
```

`<plugin_path>` is the plugin folder or its `version.php`:

```bash
./mkplgpkg.sh /var/app/moodle45lgs/0.3.3.20260618/app/mod/subcourse
```

### What it does

1. Reads `version.php` in that folder: `$plugin->component`, `$plugin->version`, and (for display) `release` and `requires`. Commented-out lines are ignored; old-style `$module->` is accepted.
2. Works out the plugin **type** and **name** and names the package with Moodle's convention: **`<type>_<name>.tar.gz`**. The top folder inside is `<name>/`.
3. Writes it to `<script folder>/plgpkgs/` (created if missing), then checks the package before finishing.

```
Plugin    : /var/app/moodle45lgs/0.3.3.20260618/app/lib/editor/atto/plugins/myplugin
Type      : atto
Name      : myplugin
Component : atto_myplugin  (from version.php)
Version   : 2024100100
Package   : /root/scripts/plgpkgs/atto_myplugin.tar.gz
Top folder: myplugin/

Created   : /root/scripts/plgpkgs/atto_myplugin.tar.gz (12 files, 16K)
SHA256    : 430b89a6...
```

### How the type is worked out

In this order:

1. The `-c` option, if given.
2. `$plugin->component` in `version.php`.
3. The folder location, using Moodle's plugin-type folders. Examples:

| Plugin folder (inside `app`) | Package name |
|---|---|
| `mod/subcourse` | `mod_subcourse.tar.gz` |
| `blocks/xp` | `block_xp.tar.gz` |
| `local/myplugin` | `local_myplugin.tar.gz` |
| `lib/editor/atto/plugins/myplugin` | `atto_myplugin.tar.gz` |
| `lib/editor/tiny/plugins/myplugin` | `tiny_myplugin.tar.gz` |
| `course/format/tiles` | `format_tiles.tar.gz` |
| `admin/tool/myplugin` | `tool_myplugin.tar.gz` |
| `question/type/myq` | `qtype_myq.tar.gz` |
| `mod/quiz/report/myrep` | `quiz_myrep.tar.gz` |
| `mod/assign/submission/mysub` | `assignsubmission_mysub.tar.gz` |
| `ai/placement/aiopenresponse` | `aiplacement_aiopenresponse.tar.gz` |
| `mod/customcert/element/bgimage` | `customcertelement_bgimage.tar.gz` (from the parent plugin's `db/subplugins.json`) |

All Moodle 4.x core plugin types are known, and subplugin types of third-party plugins are read from the parent plugin's `db/subplugins.json`. Detection works for plugins anywhere, including inside the `bkplgs/` backup folder.

If `version.php` and the folder location disagree, the `version.php` value is used and a warning is shown:

```
Warning: folder location suggests 'local_mismatch' but using 'block_mismatch' (version.php)
```

Package contents:

```
subcourse/
subcourse/version.php
subcourse/lib.php
subcourse/db/install.xml
...
```

### Options

| Option | Meaning |
|---|---|
| `-d DIR` | Output folder instead of `<script folder>/plgpkgs` |
| `-c NAME` | Force the component name (e.g. `-c local_myplugin`) |
| `-f` | Overwrite an existing package with the same name (e.g. after a plugin update) |
| `-n` | Dry run: show the details and file count, create nothing |
| `-h` | Help |

### Notes

- Left out of the package: `.git`, `.svn`, `.hg`, `.DS_Store`, `Thumbs.db`.
- File owners are stored as `0:0` (root), so the package does not depend on the server's users.
- If the folder name differs from the plugin name in `version.php`, a warning is shown and the package uses the plugin name, which is what Moodle expects.
- The package is written to a temp file first, so a failed run never leaves a broken package behind.
- The script refuses a Moodle root folder, a folder without `version.php`, and an invalid component name.

### Pack every plugin from `bkplgs.txt`

```bash
grep -v '^#' bkplgs.txt | while read -r p; do [ -n "$p" ] && ./mkplgpkg.sh "$p"; done
```

---

## 6. Troubleshooting

| Problem | Check |
|---|---|
| Too many rows from `moodle_extra_dirs.sh` | Use `-t`. Add known folders to `ignorelist`. |
| A core folder is reported as extra | It may be an **empty** folder that the build archive left out. Add it to `ignorelist`. |
| `.git`, `node_modules`, cache folders in the output | Add them to `ignorelist`. |
| Restored plugin missing `version.php` | The list was made without `-t`. Re-create it with `-t`, then `backup -o` and `restore -o`. |
| `SKIP ... use -o` | The target already exists. Check it, then re-run with `-o` if you want to overwrite. |
| `Warning: relative path needs <instance_path> argument` | Run `./bkplgs.sh backup /var/app/.../<version>` or use full paths in the list. |
| `Warning: cannot find the Moodle app folder in path` | The line is not a path inside a Moodle `app` folder. Fix the line. |
| Permission errors / wrong owner after restore | Run as root. If needed: `chown -R www-data:www-data <new_app_path>/<plugin>` |
| `cannot work out the plugin type` (mkplgpkg.sh) | No component in `version.php` and the folder is not in a known plugin-type location. Give it with `-c type_name`. |
| `package already exists` (mkplgpkg.sh) | This plugin was packed before. Use `-f` to overwrite. |