#!/usr/bin/env bash
#
# bkplgs.sh
# Back up plugin folders from an existing Moodle instance, and restore them
# into a new instance. The folders are listed in a text file "bkplgs.txt".
#
# Usage:
#   bkplgs.sh backup  [options] [instance_path]
#   bkplgs.sh restore [options] <new_app_path>
#
#   backup   copies each folder listed in bkplgs.txt (full paths, as printed by
#            moodle_extra_dirs.sh)  ->  <script dir>/bkplgs/<path inside app>
#            e.g. /var/app/moodle45lgs/0.3.3.20260618/app/local/custom
#                 ->  <script dir>/bkplgs/local/custom
#            [instance_path] is needed only if the list has relative lines.
#   restore  copies  <script dir>/bkplgs/<folder>  ->  <new_app_path>/<folder>
#
#   <script dir> is the folder holding the scripts (bkplgs.sh and
#   moodle_extra_dirs.sh). The bkplgs folder is created there on the first
#   backup if it does not exist; an existing one is used as is.
#
#   <instance_path> / <new_app_path> may be the main folder or its app folder:
#     /var/app/moodle45lgs/0.3.3.20260618
#     /var/app/moodle45lgs/0.3.9.20261118/app/
#
# Options:
#   -l FILE   List file (default: "bkplgs.txt" next to the script, then
#             "bkplgs.txt" in the current folder)
#   -b DIR    Backup folder (default: <script dir>/bkplgs)
#   -o        Overwrite: backup replaces an existing backup copy;
#             restore merges into an existing folder (files are overwritten,
#             nothing is deleted). Without -o existing targets are skipped.
#   -n        Dry run: show what would be done, change nothing
#   -h        Help
#
# List file format: one folder per line. Either relative to the app folder
#   local/customplugin
# or absolute (as printed by moodle_extra_dirs.sh)
#   /var/app/moodle45lgs/0.3.3.20260618/app/local/customplugin
# Blank lines, lines starting with # and "Info:"/"Error:" lines are ignored.
# If a folder and one of its sub-folders are both listed, only the parent is
# copied (it already contains the sub-folder).
#
# Copies preserve owner, group, permissions, timestamps and symlinks.

set -euo pipefail
export LC_ALL=C

usage() {
    sed -n '2,46p' "$0" | sed 's/^# \{0,1\}//'
    exit "${1:-0}"
}

# ---------- arguments ----------
[[ $# -ge 1 ]] || usage 1
ACTION="$1"; shift
case "$ACTION" in
    backup|restore) ;;
    -h|--help|help) usage 0 ;;
    *) echo "Error: action must be 'backup' or 'restore'" >&2; usage 1 ;;
esac

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
LIST_FILE=""
BK_ROOT="$SCRIPT_DIR/bkplgs"
OVERWRITE=0
DRYRUN=0
while getopts ":l:b:onh" opt; do
    case "$opt" in
        l) LIST_FILE="$OPTARG" ;;
        b) BK_ROOT="$OPTARG" ;;
        o) OVERWRITE=1 ;;
        n) DRYRUN=1 ;;
        h) usage 0 ;;
        :) echo "Error: -$OPTARG needs a value" >&2; usage 1 ;;
        *) echo "Error: unknown option -$OPTARG" >&2; usage 1 ;;
    esac
done
shift $((OPTIND - 1))
if [[ "$ACTION" == "restore" ]]; then
    [[ $# -eq 1 ]] || { echo "Error: restore needs the new instance path." >&2; usage 1; }
else
    [[ $# -le 1 ]] || { echo "Error: backup takes at most one path." >&2; usage 1; }
fi

# Main folder or app folder -> app folder
resolve_app() {
    local p="${1%/}"
    if [[ "$(basename "$p")" == "app" ]]; then printf '%s' "$p"
    else printf '%s/app' "$p"; fi
}

APP_DIR=""
[[ $# -eq 1 ]] && APP_DIR="$(resolve_app "$1")"
BK_ROOT="${BK_ROOT%/}"
[[ -n "$BK_ROOT" && "$BK_ROOT" != "/" ]] || { echo "Error: invalid backup folder: '$BK_ROOT'" >&2; exit 1; }

# ---------- list file ----------
if [[ -z "$LIST_FILE" ]]; then
    for f in "$SCRIPT_DIR/bkplgs.txt" "./bkplgs.txt"; do
        [[ -f "$f" ]] && { LIST_FILE="$f"; break; }
    done
fi
[[ -n "$LIST_FILE" ]]                      || { echo "Error: no 'bkplgs.txt' list file found (use -l FILE)" >&2; exit 1; }
[[ -f "$LIST_FILE" && -r "$LIST_FILE" ]]   || { echo "Error: cannot read list file: $LIST_FILE" >&2; exit 1; }

# ---------- checks per action ----------
if [[ -e "$BK_ROOT" && ! -d "$BK_ROOT" ]]; then
    echo "Error: '$BK_ROOT' exists but is a file, not a folder." >&2
    echo "       If it is an old list file, rename it: mv '$BK_ROOT' '$BK_ROOT.txt'" >&2
    exit 1
fi

if [[ "$ACTION" == "backup" ]]; then
    if [[ -n "$APP_DIR" ]]; then
        [[ -d "$APP_DIR" ]] || { echo "Error: app folder not found: $APP_DIR" >&2; exit 1; }
        APP_DIR="$(cd "$APP_DIR" && pwd -P)"
    fi
    if [[ -d "$BK_ROOT" ]]; then
        echo "Info: using existing backup folder: $BK_ROOT"
    elif (( DRYRUN )); then
        echo "Info: would create backup folder: $BK_ROOT"
    else
        mkdir -p -- "$BK_ROOT" && chmod 700 -- "$BK_ROOT"
        echo "Info: created backup folder: $BK_ROOT"
    fi
    SRC_ROOT="$APP_DIR";  DST_ROOT="$BK_ROOT"     # SRC_ROOT may be empty
else
    [[ -d "$BK_ROOT" ]] || { echo "Error: backup folder not found: $BK_ROOT" >&2; exit 1; }
    [[ -d "$APP_DIR" ]] || { echo "Error: target app folder not found: $APP_DIR" >&2; exit 1; }
    APP_DIR="$(cd "$APP_DIR" && pwd -P)"
    SRC_ROOT="$BK_ROOT";  DST_ROOT="$APP_DIR"
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# ---------- normalise list ----------
# CR, comments, spaces, script info lines; absolute paths -> part after "/app/"
sed -e 's/\r$//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
    -e '/^#/d' -e '/^Info:/d' -e '/^Error:/d' -e '/^$/d' "$LIST_FILE" > "$TMP/raw"

# Absolute path -> path relative to its Moodle app folder.
# Paths like /var/app/<name>/<version>/app/local/x contain "/app/" more than
# once, so the right one is chosen by:
#   1. an "app" folder that is a Moodle root (has version.php + lib/moodlelib.php)
#   2. otherwise an "app" folder right after a version-like folder (0.3.3.20260618)
strip_app_root() {
    local p="$1" pre="" rest="$1" comp fallback=""
    rest="${rest#/}"
    while [[ "$rest" == */* ]]; do
        comp="${rest%%/*}"; rest="${rest#*/}"
        if [[ "$comp" == "app" ]]; then
            if [[ -f "$pre/app/version.php" && -f "$pre/app/lib/moodlelib.php" ]]; then
                printf '%s' "$rest"; return 0
            fi
            if [[ -z "$fallback" && "$(basename "${pre:-/}")" =~ ^[0-9]+(\.[0-9]+)+$ ]]; then
                fallback="$rest"
            fi
        fi
        pre="$pre/$comp"
    done
    [[ -n "$fallback" ]] && { printf '%s' "$fallback"; return 0; }
    return 1
}

BAD=0
: > "$TMP/rel"
while IFS= read -r line; do
    p="${line//\\//}"
    while [[ "$p" == *//* ]]; do p="${p//\/\//\/}"; done
    while [[ "$p" == ?*/ ]]; do p="${p%/}"; done
    abs=""
    if [[ "$p" == /* ]]; then
        abs="$p"                                       # backup copies from here
        if [[ -n "$APP_DIR" && "$p/" == "$APP_DIR/"* ]]; then
            p="${p#"$APP_DIR"/}"
        elif ! p="$(strip_app_root "$p")"; then
            echo "Warning: cannot find the Moodle app folder in path, skipped: $line" >&2
            BAD=$((BAD+1)); continue
        fi
    elif [[ "$ACTION" == "backup" && -z "$APP_DIR" ]]; then
        echo "Warning: relative path needs <instance_path> argument, skipped: $line" >&2
        BAD=$((BAD+1)); continue
    fi
    p="${p#./}"; p="${p#app/}"
    while [[ "$p" == */ ]]; do p="${p%/}"; done
    if [[ -z "$p" || "$p" == ".." || "$p" == ../* || "$p" == */.. || "$p" == */../* || "$abs" == *"/../"* || "$abs" == */.. ]]; then
        echo "Warning: unsafe or empty path, skipped: $line" >&2; BAD=$((BAD+1)); continue
    fi
    [[ -z "$abs" ]] && abs="${APP_DIR:+$APP_DIR/$p}"
    printf '%s\t%s\n' "$p" "$abs" >> "$TMP/rel"
done < "$TMP/raw"

# Drop duplicates and folders whose parent is also listed (by app-relative path)
sort -t $'\t' -k1,1 -u "$TMP/rel" | awk -F '\t' '
    { rel[NR] = $1; line[NR] = $0; inlist[$1] = 1 }
    END {
        for (i = 1; i <= NR; i++) {
            p = rel[i]; keep = 1
            while (sub(/\/[^\/]*$/, "", p)) if (p in inlist) { keep = 0; break }
            if (keep) print line[i]
        }
    }' > "$TMP/list"

TOTAL=$(wc -l < "$TMP/list")
(( TOTAL > 0 )) || { echo "Error: no folders to process in $LIST_FILE" >&2; exit 1; }

echo "Action : $ACTION$( (( DRYRUN )) && echo ' (dry run)')"
echo "List   : $LIST_FILE ($TOTAL folders)"
echo "From   : ${SRC_ROOT:-paths in the list file}"
echo "To     : $DST_ROOT"
echo

# ---------- copy ----------
OK=0; SKIP=0; FAIL=0
while IFS=$'\t' read -r rel abs; do
    if [[ "$ACTION" == "backup" ]]; then src="$abs"; else src="$SRC_ROOT/$rel"; fi
    dst="$DST_ROOT/$rel"

    if [[ ! -d "$src" ]]; then
        echo "MISSING  $rel  (not found: $src)"; FAIL=$((FAIL+1)); continue
    fi

    if [[ -e "$dst" ]]; then
        if (( ! OVERWRITE )); then
            echo "SKIP     $rel  (already exists: $dst, use -o)"; SKIP=$((SKIP+1)); continue
        fi
        if (( DRYRUN )); then
            echo "WOULD    $rel  ($( [[ $ACTION == backup ]] && echo replace || echo merge ) existing)"; OK=$((OK+1)); continue
        fi
        if [[ "$ACTION" == "backup" ]]; then
            rm -rf -- "$dst"                    # refresh backup copy (inside backup folder only)
        fi
    elif (( DRYRUN )); then
        echo "WOULD    $rel"; OK=$((OK+1)); continue
    fi

    if mkdir -p -- "$dst" && cp -a -- "$src/." "$dst/"; then
        echo "COPIED   $rel"; OK=$((OK+1))
    else
        echo "FAILED   $rel"; FAIL=$((FAIL+1))
    fi
done < "$TMP/list"

echo
echo "Done: $OK copied, $SKIP skipped, $FAIL failed$( (( BAD )) && echo ", $BAD invalid list lines")"
(( FAIL == 0 && BAD == 0 ))