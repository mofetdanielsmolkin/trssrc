#!/usr/bin/env bash
#
# mkplgpkg.sh
# Packs one Moodle plugin folder into a tar.gz laid out like a Moodle plugin
# install package: one top folder named after the plugin, files inside.
# Named with Moodle's plugin naming: <type>_<name>.tar.gz
#
# Usage:
#   mkplgpkg.sh [options] <plugin_path>
#
#   <plugin_path>  the plugin folder, or its version.php, e.g.
#                  /var/app/moodle45lgs/0.3.3.20260618/app/lib/editor/atto/plugins/myplugin
#
# Output:
#   <script dir>/plgpkgs/<type>_<name>.tar.gz
#   e.g. plgpkgs/atto_myplugin.tar.gz   containing  myplugin/version.php, ...
#        plgpkgs/mod_subcourse.tar.gz   containing  subcourse/version.php, ...
#
# The type_name (component) is taken from, in this order:
#   1. -c option
#   2. $plugin->component in version.php
#   3. the folder location (lib/editor/atto/plugins/x -> atto_x, blocks/x ->
#      block_x, mod/assign/submission/x -> assignsubmission_x, ...), including
#      subplugin types declared in a parent plugin's db/subplugins.json
# A warning is shown if version.php and the folder location disagree.
#
# Options:
#   -d DIR    Output folder (default: <script dir>/plgpkgs, created if missing)
#   -c NAME   Component name to force (e.g. local_myplugin)
#   -f        Overwrite an existing package with the same name
#   -n        Dry run: show what would be packed, create nothing
#   -h        Help
#
# Left out of the package: .git, .svn, .hg, .DS_Store, Thumbs.db
# File owners are stored as 0:0 (root) so the package is portable.

set -euo pipefail
export LC_ALL=C

usage() {
    sed -n '2,38p' "$0" | sed 's/^# \{0,1\}//'
    exit "${1:-0}"
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
OUT_DIR="$SCRIPT_DIR/plgpkgs"
COMPONENT_OVERRIDE=""
FORCE=0
DRYRUN=0
while getopts ":d:c:fnh" opt; do
    case "$opt" in
        d) OUT_DIR="${OPTARG%/}" ;;
        c) COMPONENT_OVERRIDE="$OPTARG" ;;
        f) FORCE=1 ;;
        n) DRYRUN=1 ;;
        h) usage 0 ;;
        :) echo "Error: -$OPTARG needs a value" >&2; usage 1 ;;
        *) echo "Error: unknown option -$OPTARG" >&2; usage 1 ;;
    esac
done
shift $((OPTIND - 1))
[[ $# -eq 1 ]] || { echo "Error: one plugin path required." >&2; usage 1; }

# ---------- locate plugin folder and version.php ----------
IN="${1%/}"
[[ -n "$IN" ]] || IN="/"
if [[ -f "$IN" && "$(basename "$IN")" == "version.php" ]]; then
    PLUGIN_DIR="$(dirname "$IN")"
elif [[ -d "$IN" ]]; then
    PLUGIN_DIR="$IN"
else
    echo "Error: not a folder or version.php: $IN" >&2; exit 1
fi
PLUGIN_DIR="$(cd "$PLUGIN_DIR" && pwd -P)"
VERSION_FILE="$PLUGIN_DIR/version.php"
[[ -f "$VERSION_FILE" && -r "$VERSION_FILE" ]] || { echo "Error: version.php not found in: $PLUGIN_DIR" >&2; exit 1; }

# Refuse a Moodle root (its version.php has $version / $release, not $plugin)
if [[ -f "$PLUGIN_DIR/lib/moodlelib.php" ]]; then
    echo "Error: $PLUGIN_DIR is a Moodle root folder, not a plugin." >&2; exit 1
fi

# ---------- read version.php ----------
# Reads  $plugin->KEY = VALUE;  (also old-style $module->KEY), ignoring comments.
# Prints the value without quotes; empty if not set.
read_prop() {
    local key="$1"
    sed -e 's/\r$//' -e 's#//.*$##' -e 's/^[[:space:]]*#.*$//' "$VERSION_FILE" \
    | tr '\n' ' ' | sed -e 's#/\*[^*]*\*\+\([^/*][^*]*\*\+\)*/##g' -e 's/<?php//g' | tr ';' '\n' \
    | sed -n -E "s/^[[:space:]]*\\\$(plugin|module)[[:space:]]*->[[:space:]]*${key}[[:space:]]*=[[:space:]]*(.*[^[:space:]])[[:space:]]*\$/\\2/p" \
    | tail -n 1 \
    | sed -E -e "s/^'(.*)'\$/\\1/" -e 's/^"(.*)"$/\1/'
}

VP_COMPONENT="$(read_prop component)"
VERSION="$(read_prop version)"
RELEASE="$(read_prop release)"
REQUIRES="$(read_prop requires)"

# ---------- plugin type from the folder location ----------
# Moodle 4.x core plugin types: <type> <folder inside app>
# (from lib/components.json and the core subplugins.json files)
CORE_TYPES='
antivirus lib/antivirus
availability availability/condition
qtype question/type
mod mod
auth auth
calendartype calendar/type
customfield customfield/field
enrol enrol
message message/output
dataformat dataformat
webservice webservice
repository repository
portfolio portfolio
search search/engine
media media/player
plagiarism plagiarism
cachestore cache/stores
cachelock cache/locks
fileconverter files/converter
contenttype contentbank/contenttype
theme theme
local local
h5plib h5p/h5plib
paygw payment/gateway
smsgateway sms/gateway
communication communication/provider
aiprovider ai/provider
aiplacement ai/placement
block blocks
qbank question/bank
qbehaviour question/behaviour
qformat question/format
filter filter
editor lib/editor
atto lib/editor/atto/plugins
tiny lib/editor/tiny/plugins
tinymce lib/editor/tinymce/plugins
format course/format
profilefield user/profile/field
report report
coursereport course/report
gradeexport grade/export
gradeimport grade/import
gradereport grade/report
gradingform grade/grading/form
mlbackend lib/mlbackend
mnetservice mnet/service
tool admin/tool
logstore admin/tool/log/store
factor admin/tool/mfa/factor
assignsubmission mod/assign/submission
assignfeedback mod/assign/feedback
booktool mod/book/tool
datafield mod/data/field
datapreset mod/data/preset
forumreport mod/forum/report
ltisource mod/lti/source
ltiservice mod/lti/service
quiz mod/quiz/report
quizaccess mod/quiz/accessrule
scormreport mod/scorm/report
workshopform mod/workshop/form
workshopallocation mod/workshop/allocation
workshopeval mod/workshop/eval
'

# Subplugin types declared by parent plugins (db/subplugins.json), so third-party
# subplugins are recognised too, e.g. mod/customcert/element -> customcertelement.
# Prints "<type> <absolute folder>" lines.
subplugin_types() {
    local d="$PLUGIN_DIR" json
    while d="$(dirname "$d")"; [[ "$d" != "/" ]]; do
        json="$d/db/subplugins.json"
        [[ -f "$json" ]] || continue
        if command -v php >/dev/null 2>&1; then
            php -r '
                $j = json_decode(file_get_contents($argv[1]), true); $d = $argv[2];
                if (!is_array($j)) exit;
                foreach (($j["subplugintypes"] ?? []) as $t => $p) echo "$t $d/$p\n";
                if (empty($j["subplugintypes"])) foreach (($j["plugintypes"] ?? []) as $t => $p) echo "$t /$p\n";
            ' "$json" "$d" 2>/dev/null || true
        elif command -v python3 >/dev/null 2>&1; then
            python3 -I -c '
import json, sys
try: j = json.load(open(sys.argv[1]))
except Exception: sys.exit()
d = sys.argv[2]
s = j.get("subplugintypes") or {}
for t, p in s.items(): print(t, d + "/" + p)
if not s:
    for t, p in (j.get("plugintypes") or {}).items(): print(t, "/" + p)
' "$json" "$d" 2>/dev/null || true
        fi
    done
}

# Match the plugin's parent folder against the known type folders;
# the longest match wins (mod/quiz/report beats report).
PARENT_DIR="$(dirname "$PLUGIN_DIR")"
DIR_NAME="$(basename "$PLUGIN_DIR")"
PATH_TYPE=""; best_len=0
while read -r t base; do
    [[ -n "$t" && -n "$base" ]] || continue
    base="${base%/}"
    if [[ "$base" == /* ]]; then
        # absolute (from subplugintypes) or "/<path from app root>" (old plugintypes)
        [[ "$PARENT_DIR" == "$base" || "$PARENT_DIR" == *"$base" ]] || continue
    else
        [[ "$PARENT_DIR" == */"$base" ]] || continue
    fi
    if (( ${#base} > best_len )); then PATH_TYPE="$t"; best_len=${#base}; fi
done < <(printf '%s\n' "$CORE_TYPES"; subplugin_types)

PATH_COMPONENT=""
[[ -n "$PATH_TYPE" ]] && PATH_COMPONENT="${PATH_TYPE}_${DIR_NAME}"

# ---------- decide the component ----------
# Priority: -c  >  version.php  >  folder location
if [[ -n "$COMPONENT_OVERRIDE" ]]; then
    COMPONENT="$COMPONENT_OVERRIDE"; SOURCE="-c option"
elif [[ -n "$VP_COMPONENT" ]]; then
    COMPONENT="$VP_COMPONENT"; SOURCE="version.php"
elif [[ -n "$PATH_COMPONENT" ]]; then
    COMPONENT="$PATH_COMPONENT"; SOURCE="folder location"
else
    echo "Error: cannot work out the plugin type." >&2
    echo "       version.php has no \$plugin->component and the folder" >&2
    echo "       '$PARENT_DIR' is not a known Moodle plugin type folder." >&2
    echo "       Give it with -c, e.g.  -c local_$DIR_NAME" >&2
    exit 1
fi

if [[ -n "$PATH_COMPONENT" && "$PATH_COMPONENT" != "$COMPONENT" ]]; then
    echo "Warning: folder location suggests '$PATH_COMPONENT' but using '$COMPONENT' ($SOURCE)" >&2
fi
if [[ -n "$COMPONENT_OVERRIDE" && -n "$VP_COMPONENT" && "$VP_COMPONENT" != "$COMPONENT_OVERRIDE" ]]; then
    echo "Warning: version.php says '$VP_COMPONENT', using -c '$COMPONENT_OVERRIDE'" >&2
fi

[[ "$COMPONENT" =~ ^[a-z][a-z0-9]*_[a-z0-9_]+$ ]] || { echo "Error: invalid component name: '$COMPONENT'" >&2; exit 1; }
[[ -n "$VERSION" ]] || { echo "Error: \$plugin->version not found in $VERSION_FILE" >&2; exit 1; }
[[ "$VERSION" =~ ^[0-9]+(\.[0-9]+)?$ ]] || { echo "Error: unexpected version value: '$VERSION'" >&2; exit 1; }

PLUGIN_TYPE="${COMPONENT%%_*}"                    # atto_myplugin -> atto
PLUGIN_NAME="${COMPONENT#*_}"                     # atto_myplugin -> myplugin
if [[ "$DIR_NAME" != "$PLUGIN_NAME" ]]; then
    echo "Warning: folder is '$DIR_NAME' but plugin name is '$PLUGIN_NAME';" \
         "the package will use '$PLUGIN_NAME/' (what Moodle expects)" >&2
fi

PKG_NAME="${COMPONENT}.tar.gz"
PKG_PATH="$OUT_DIR/$PKG_NAME"

EXCLUDES=( --exclude=.git --exclude=.svn --exclude=.hg --exclude=.DS_Store --exclude=Thumbs.db )

echo "Plugin    : $PLUGIN_DIR"
echo "Type      : $PLUGIN_TYPE"
echo "Name      : $PLUGIN_NAME"
echo "Component : $COMPONENT  (from $SOURCE)"
echo "Version   : $VERSION"
[[ -n "$RELEASE"  ]] && echo "Release   : $RELEASE"
[[ -n "$REQUIRES" ]] && echo "Requires  : $REQUIRES"
echo "Package   : $PKG_PATH"
echo "Top folder: $PLUGIN_NAME/"

# ---------- output folder / existing package ----------
if [[ -e "$OUT_DIR" && ! -d "$OUT_DIR" ]]; then
    echo "Error: output path exists and is not a folder: $OUT_DIR" >&2; exit 1
fi
if [[ -e "$PKG_PATH" && $FORCE -eq 0 ]]; then
    echo "Error: package already exists: $PKG_PATH (use -f to overwrite)" >&2; exit 1
fi
case "$OUT_DIR/" in
    "$PLUGIN_DIR"/*) echo "Error: output folder must not be inside the plugin folder" >&2; exit 1 ;;
esac

if (( DRYRUN )); then
    N=$(cd "$PLUGIN_DIR" && find . \( -name .git -o -name .svn -o -name .hg \) -prune -o \
          -type f ! -name .DS_Store ! -name Thumbs.db -print | wc -l)
    echo
    echo "Dry run: would pack $N files. Nothing created."
    exit 0
fi

if [[ ! -d "$OUT_DIR" ]]; then
    mkdir -p -- "$OUT_DIR"
    echo "Info: created output folder: $OUT_DIR"
fi

# ---------- pack ----------
# Write to a temp file first, so a failed run never leaves a broken package.
TMP_PKG="$(mktemp "$OUT_DIR/.${PKG_NAME}.XXXXXX")"
trap 'rm -f "$TMP_PKG"' EXIT

TAR_OPTS=( --owner=0 --group=0 --numeric-owner )
tar --help 2>/dev/null | grep -q -- '--sort' && TAR_OPTS+=( --sort=name )

# --transform renames the top folder to the plugin name without copying files
tar "${TAR_OPTS[@]}" "${EXCLUDES[@]}" \
    -C "$(dirname "$PLUGIN_DIR")" \
    --transform "s#^${DIR_NAME//./\\.}\\(/\\|\$\\)#${PLUGIN_NAME}\\1#" \
    -czf "$TMP_PKG" "$DIR_NAME"

# ---------- verify ----------
LISTING="$(tar -tzf "$TMP_PKG")" || { echo "Error: package check failed" >&2; exit 1; }
TOPS="$(printf '%s\n' "$LISTING" | sed 's#^\./##' | cut -d/ -f1 | sort -u)"
[[ "$TOPS" == "$PLUGIN_NAME" ]] || { echo "Error: unexpected top folder(s) in package: $TOPS" >&2; exit 1; }
printf '%s\n' "$LISTING" | grep -qx "$PLUGIN_NAME/version.php" || { echo "Error: version.php missing in package" >&2; exit 1; }

chmod 644 "$TMP_PKG"
mv -f -- "$TMP_PKG" "$PKG_PATH"
trap - EXIT

FILES=$(printf '%s\n' "$LISTING" | grep -vc '/$' || true)
SIZE=$(du -h "$PKG_PATH" | cut -f1)
echo
echo "Created   : $PKG_PATH ($FILES files, $SIZE)"
command -v sha256sum >/dev/null && echo "SHA256    : $(sha256sum "$PKG_PATH" | cut -d' ' -f1)"