#!/usr/bin/env bash
#
# moodle_extra_dirs.sh
# Lists folders that exist in an installed Moodle instance but NOT in the
# Moodle custom build tar.gz (i.e. extra plugins installed on the server).
# Compares folder structure only; files are ignored. Nothing is extracted.
#
# Usage:
#   moodle_extra_dirs.sh [-t|-f] [-r] [-a app_dir] [-i ignore_file]
#                        <moodle_build.tar.gz> <instance_path>
#
#   <moodle_build.tar.gz>  custom build archive
#   <instance_path>        main folder of the existing instance (contains ./app)
#
# Output (default): deepest extra folders only - a folder that has extra
#                   sub-folders is not printed as its own row
# Options:
#   -t          Top-level only: print the plugin root, not its sub-folders
#   -f          Full: print every extra folder (parents and sub-folders)
#   -r          Print paths relative to the app folder (default: absolute)
#   -a NAME     Name of the application folder (default: app)
#   -i FILE     Ignore list file (default: "ignorelist" next to the script,
#               then "ignorelist" in the current folder, if one exists)
#   -p PATH     Extra source folder in the archive whose contents count as if
#               they were inside the app folder. Repeatable.
#               (default: PrivatePlugins/lib  ->  e.g. PrivatePlugins/lib/mod/subcourse
#                is treated as app/mod/subcourse; skipped if not in the archive)
#   -P          Do not use any extra source folder
#   -h          Help
#
# Ignore list format: one folder per line, relative to the app folder.
# The folder and everything under it is skipped. Blank lines and lines
# starting with # are ignored. Example:
#   local/accessibility
#   mod/choicegroup

set -euo pipefail
export LC_ALL=C

usage() {
    sed -n '2,35p' "$0" | sed 's/^# \{0,1\}//'
    exit "${1:-0}"
}

MODE="leaf"
RELATIVE=0
APP="app"
IGNORE_FILE=""
SOURCES=()
SOURCES_SET=0
norm_path() {           # "\" -> "/", drop leading ./ and leading/trailing slashes
    local p="${1//\\//}"
    p="${p#./}"; while [[ "$p" == /* ]]; do p="${p#/}"; done
    while [[ "$p" == */ ]]; do p="${p%/}"; done
    printf '%s' "$p"
}
while getopts ":tfra:i:p:Ph" opt; do
    case "$opt" in
        t) MODE="top" ;;
        f) MODE="full" ;;
        r) RELATIVE=1 ;;
        a) APP="$(norm_path "$OPTARG")" ;;
        p) SOURCES+=( "$(norm_path "$OPTARG")" ); SOURCES_SET=1 ;;
        P) SOURCES=(); SOURCES_SET=1 ;;
        i) IGNORE_FILE="$OPTARG" ;;
        h) usage 0 ;;
        :) echo "Error: -$OPTARG needs a value" >&2; usage 1 ;;
        *) echo "Error: unknown option -$OPTARG" >&2; usage 1 ;;
    esac
done
shift $((OPTIND - 1))
(( SOURCES_SET )) || SOURCES=( "PrivatePlugins/lib" )

[[ $# -eq 2 ]] || { echo "Error: two arguments required." >&2; usage 1; }

TARBALL="$1"
INSTANCE="${2%/}"

[[ -f "$TARBALL" && -r "$TARBALL" ]] || { echo "Error: cannot read archive: $TARBALL" >&2; exit 1; }
[[ -d "$INSTANCE" ]]                 || { echo "Error: instance folder not found: $INSTANCE" >&2; exit 1; }
[[ -d "$INSTANCE/$APP" ]]            || { echo "Error: '$APP' folder not found in: $INSTANCE" >&2; exit 1; }
gzip -t "$TARBALL" 2>/dev/null       || { echo "Error: not a valid gzip archive: $TARBALL" >&2; exit 1; }

# Resolve the ignore list
if [[ -n "$IGNORE_FILE" ]]; then
    [[ -f "$IGNORE_FILE" && -r "$IGNORE_FILE" ]] || { echo "Error: cannot read ignore list: $IGNORE_FILE" >&2; exit 1; }
else
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
    for f in "$SCRIPT_DIR/ignorelist" "./ignorelist"; do
        [[ -f "$f" && -r "$f" ]] && { IGNORE_FILE="$f"; break; }
    done
fi

INST_APP="$(cd "$INSTANCE/$APP" && pwd -P)"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# 0. Normalise the ignore list: strip CR (Windows), spaces, comments,
#    leading "./" or "app/", leading/trailing slashes
: > "$TMP/ignore"
if [[ -n "$IGNORE_FILE" ]]; then
    sed -e 's/\r$//' -e 's/#.*$//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
        -e 's#^\(\./\)*##' -e "s#^/*${APP}/##" -e 's#^/*##' -e 's#/*$##' \
        "$IGNORE_FILE" | sed '/^$/d' | sort -u > "$TMP/ignore"
    echo "Info: ignore list: $IGNORE_FILE ($(wc -l < "$TMP/ignore") entries)" >&2
fi

# 1. Archive entry names (listing only); Windows "\" separators -> "/"
#    GNU tar escapes "\" and non-ASCII names when listing; ask for raw names
TAR_OPTS=()
tar --version 2>/dev/null | grep -q 'GNU tar' && TAR_OPTS=( --quoting-style=literal )
tar ${TAR_OPTS[@]+"${TAR_OPTS[@]}"} -tzf "$TARBALL" \
    | sed -e 's#\\#/#g' -e 's#//*#/#g' -e 's#^\(\./\)*##' -e '/^$/d' > "$TMP/entries"

# Find the shallowest prefix in the archive that ends with "<target>/"
# (target may be several components, e.g. "PrivatePlugins/lib")
find_prefix() {
    awk -v t="$1" '
    {
        s = "/" $0
        i = index(s, "/" t "/")
        if (i > 0) {
            pre = substr(s, 2, i + length(t))
            if (best == "" || length(pre) < length(best)) best = pre
        }
    }
    END { print best }' "$TMP/entries"
}

# List every folder under a prefix, relative to it
# (explicit directory entries + parent folders of files)
dirs_under() {
    awk -v pre="$1" '
    index($0, pre) == 1 {
    p = substr($0, length(pre) + 1)
    if (p == "") next
    if (p ~ /\/$/) { sub(/\/+$/, "", p) }        # directory entry
    else if (index(p, "/") == 0) next            # file directly in app/
    else { sub(/\/[^\/]*$/, "", p) }             # file -> its folder
    n = split(p, part, "/")
    acc = ""
    for (i = 1; i <= n; i++) {
        acc = (i == 1) ? part[1] : acc "/" part[i]
        print acc
    }
}' "$TMP/entries"
}

# 2. Locate the app folder in the archive
PREFIX="$(find_prefix "$APP")"
[[ -n "$PREFIX" ]] || { echo "Error: no '$APP/' folder found inside the archive" >&2; exit 1; }
echo "Info: archive app folder: '$PREFIX'" >&2

# 3. Folders from the app folder + every extra source folder (-p),
#    whose contents count as if they were inside the app folder
dirs_under "$PREFIX" > "$TMP/tar_dirs_raw"
for src in ${SOURCES[@]+"${SOURCES[@]}"}; do
    SPRE="$(find_prefix "$src")"
    if [[ -n "$SPRE" ]]; then
        echo "Info: extra source folder: '$SPRE' (treated as '$APP/')" >&2
        dirs_under "$SPRE" >> "$TMP/tar_dirs_raw"
    else
        echo "Info: extra source folder '$src/' not found in archive - skipped" >&2
    fi
done
sort -u "$TMP/tar_dirs_raw" > "$TMP/tar_dirs"

# 4. Every folder under the instance app folder (symlinks not followed).
#    Ignored folders are pruned: they and their sub-folders are not scanned.
PRUNE=()
while IFS= read -r ign; do
    PRUNE+=( -path "$INST_APP/$ign" -o )
done < "$TMP/ignore"

if (( ${#PRUNE[@]} )); then
    unset 'PRUNE[${#PRUNE[@]}-1]'              # drop trailing -o
    find "$INST_APP" -mindepth 1 \( "${PRUNE[@]}" \) -prune -o -type d -printf '%P\n'
else
    find "$INST_APP" -mindepth 1 -type d -printf '%P\n'
fi | sort -u > "$TMP/inst_dirs"

# 5. Folders in instance but not in archive
comm -23 "$TMP/inst_dirs" "$TMP/tar_dirs" > "$TMP/extra"

# 6. Shape the list
#    default : deepest folders only (a folder whose sub-folders are listed is hidden)
#    -t      : top-most folders only (sub-folders of a listed folder are hidden)
#    -f      : every folder
if [[ "$MODE" != "full" ]]; then
    awk -v mode="$MODE" '
        { path[NR] = $0; inlist[$0] = 1 }
        END {
            for (i = 1; i <= NR; i++) {
                p = path[i]
                while (sub(/\/[^\/]*$/, "", p)) {          # walk up the ancestors
                    if (p in inlist) {
                        if (mode == "top") { drop[path[i]] = 1 }
                        else               { drop[p] = 1 }   # ancestor has children
                    }
                }
            }
            for (i = 1; i <= NR; i++) if (!(path[i] in drop)) print path[i]
        }' "$TMP/extra" > "$TMP/extra_shaped"
    mv "$TMP/extra_shaped" "$TMP/extra"
fi

# 7. Output
if (( RELATIVE )); then
    cat "$TMP/extra"
else
    while IFS= read -r d; do printf '%s/%s\n' "$INST_APP" "$d"; done < "$TMP/extra"
fi

echo "Info: $(wc -l < "$TMP/extra") folder(s) found in instance but not in archive" >&2